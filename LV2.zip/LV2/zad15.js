var rando = require('./slucajniBroj');

var br1 = rando.dajSlucajanBroj(10,100);
var br2 = rando.dajSlucajanBroj(10,100);
var br3 = rando.dajSlucajanBroj(10,100);

console.log(br1);
console.log(br2);
console.log(br3);

var znm1 = parseInt(br1.toString()[br1.toString().length - 1]);
var znm2 = parseInt(br2.toString()[br2.toString().length - 1]);
var znm3 = parseInt(br3.toString()[br3.toString().length - 1]);

if(znm1==znm2)
{
    console.log("true");
}
else if(znm2 == znm3)
{
    console.log("true");
}
else if(znm1 == znm3)
{
    console.log("true");
}
else
{
    console.log("Nema istih brojeva");
}