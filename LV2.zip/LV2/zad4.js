var i = 1;
var sum = 0;
var n = 0;

while(i <= 100)
{
    if(n % 2 != 0)
    {
        sum += n;
        i++
    }
    n++;
}

console.log(sum);