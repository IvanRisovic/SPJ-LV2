var i = 1;

for(i = 1; i <= 100; i++)
{
    if(i % 5 == 0 && i % 7 == 0)
    {
        console.log("Broj " + i + " je dijeljiv i sa 5 i sa 7");
    }
    else if(i % 7 == 0)
    {
        console.log("Broj " + i + " je dijeljiv sa 7");
    }
    else if(i % 5 == 0 )
    {
        console.log("Broj " + i + " je dijeljiv s 5");
    }
}