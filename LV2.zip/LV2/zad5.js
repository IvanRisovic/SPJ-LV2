var aPolje = [];

var i = 1;

for(i = 1; i <= 50; i++)
{
    if(i % 7 == 0)
    {
        aPolje.push(i);
    }
}

aPolje.forEach(function(i){
    console.log(i);
})