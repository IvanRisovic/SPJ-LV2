import dajSlucajanBroj from "./slucajniBroj.js";

var i = 1;
var aBrojevi = [];

for(i = 1; i <= 50; i++)
{
    aBrojevi.push(dajSlucajanBroj(1,20))
}

for(var i = 1; i <= 20; i++)
{
    if(aBrojevi.indexOf(i) > -1)
    {
        console.log(i)
    }
}