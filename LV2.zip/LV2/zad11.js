var http = require('http');
var nOsobe = require('./osobe.json');
var nPort = 8000;

console.log('Pokretanje servera na portu '+nPort);
http.createServer(function(request, response){
    response.writeHead(200, {'Content-Type': 'text/plain; charset=utf-8'});
    nOsobe.forEach(function(n){
        response.write(n.index + " " + n.age + " " + n.name + " " + n.company + "\n")
    })
    response.end();
}).listen(nPort);
