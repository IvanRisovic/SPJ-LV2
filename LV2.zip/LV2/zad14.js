var num = 1874;

var numStr = num.toString();
var newStr = "";

if(num > 99)
{
    newStr +=  (parseInt(numStr[0]) + parseInt(numStr[numStr.length - 1])).toString();    
}
else
{
    console.log("Broj je prekratak.");
}
console.log(newStr);