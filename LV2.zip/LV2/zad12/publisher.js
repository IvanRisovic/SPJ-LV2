var mqtt = require('mqtt');
var client = mqtt.connect('mqtt://127.0.0.1');
client.on('connect', function() {
    console.log('Publisher is online!');
    setInterval(function() {
        var temp = 23;
        client.publish('temp', 'Trenutna temperatura je: ' + temp.toString());
console.log('Message sent!');
}, 5000);
});