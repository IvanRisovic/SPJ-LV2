var rando = require('./slucajniBroj');
var aBrojevi = [];

var i = 1;

for(i = 1; i <= 30; i++)
{
    aBrojevi.push(rando.dajSlucajanBroj(10, 200));
}

var done = false;
while(!done)
{
    done = true;
    for(var i = 1; i < aBrojevi.length; i++)
    {
        if(aBrojevi[i - 1] > aBrojevi[i])
        {
            done = false;
            var tmp = aBrojevi[i - 1];
            aBrojevi[i - 1] = aBrojevi[i];
            aBrojevi[i] = tmp;
        }
    }
}

aBrojevi.forEach(function(n){
    console.log(n);
})