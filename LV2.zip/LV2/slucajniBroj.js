exports.dajSlucajanBroj = function(nMin, nMax)
{
 return Math.floor(Math.random() * (nMax - nMin + 1) + nMin);
}