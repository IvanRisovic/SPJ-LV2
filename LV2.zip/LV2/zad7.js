import dajSlucajanBroj from "./slucajniBroj.js";

var i = 1;
var aBrojevi = [];

for(i = 1; i <=200; i++)
{
    aBrojevi.push(dajSlucajanBroj(150, 1500));
}

var max = 0;
var min = 1501;

aBrojevi.forEach(function(num){
    if(num > max)
    {
        max = num;
    }
    else if(num < min)
    {
        min = num;
    }
});

console.log(max);
console.log(min);