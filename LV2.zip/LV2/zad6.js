import dajSlucajanBroj from "./slucajniBroj.js";

var i = 50;
var aBrojevi = [];

for(i = 1; i <= 100; i++)
{
    aBrojevi.push(dajSlucajanBroj(50, 5000));
}

var br = 0;

aBrojevi.forEach(function(nBroj){
    if(nBroj % 2 == 0)
    {
        br++;
    }
});

console.log(br);
console.log(100 - br);